This folder contains code implementation details,PLOTS
related to the Bayesian SIR project.
